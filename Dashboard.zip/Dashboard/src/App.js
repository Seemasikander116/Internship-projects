import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

import SideBar from './components/SideNavBar'

import Home from "./components/Home";
import AddArticle from './components/AddArticle';
import EditArticle from './components/EditArticle';
import ViewArticle from './components/ViewArticle'
import AddAssignment from './components/AddAssignment';
import EditAssignment from './components/EditAssignment';
import Profile from './components/Teacher/Profile';


import { Container, Row, Col, Card, Button } from 'react-bootstrap';



import './assets/css/style.css'

// import './App.css';
import { makeStyles, useTheme } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
  },
  toolbar: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar,
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3),
  },
}));

function App() {
  const classes = useStyles();

  return (
    <Router>
      <>

        <div className={classes.root}>

          <SideBar />
          <main className={classes.content}>
            <div className={classes.toolbar} />
            <Switch>
              <Route exact from="/" render={props => <Home {...props} />} />
              <Route exact path="/article/add" render={props => <AddArticle {...props} />} />
              <Route exact path="/article/edit" render={props => <EditArticle {...props} />} />
              <Route exact path="/article/view" render={props => <ViewArticle {...props} />} />
              <Route exact path="/assignment/add" render={props => <AddAssignment {...props} />} />
              <Route exact path="/assignment/edit" render={props => <EditAssignment {...props} />}               <Route exact path="/profile" render={props => <Profile {...props} />} />
            </Switch>
          </main>
        </div>
      </>
    </Router>
  );
}

export default App;
