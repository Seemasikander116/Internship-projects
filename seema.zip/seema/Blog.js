import React from "react";
import '../Appp.css';
function Blog() {
  return (
    <>
      <div>
        <div className="blog">
          <h1 style={{ fontWeight: "bold" }}>BLOG PAGE</h1>
        </div>
        <br></br>
        <div className="Blogimg">
          <div className="blog-post-date">Feb 19, 2021</div>
        </div>
      </div>
    </>
  );
}

export default Blog;
