const JobData=[
        
    {
        location:'QBL Park, C40',
        companyname:'Senior front-end Developer',
        jobtype:'Full Time',
        organization:'google',
        salary:'$810-987',
        img:'../img/banner-3.jpg',
        num:1,

    }
    ,{
        location:'QBL Park, C40',
        companyname:'Senior front-end ',
        jobtype:'Full Time',
        organization:'google',
        salary:'$810-987',
        img:'../img/banner-3.jpg',
        num:1,
    },
    {
        location:'QBL Park, C40',
        companyname:'Senior front-end Developer',
        jobtype:'Full Time',
        organization:'google',
        salary:'$810-987',
        img:'../img/banner-3.jpg',

    }
];

export default JobData;