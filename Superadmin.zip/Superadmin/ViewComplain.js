import React from "react"
const ViewComplain=()=>{
    return(<>
        
        </>
        )
} 
export default ViewComplain